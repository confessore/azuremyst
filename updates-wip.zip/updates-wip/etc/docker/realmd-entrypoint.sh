#!/bin/sh

/azuremyst/src/mangos/run/bin/realmd -c /azuremyst/src/mangos/run/etc/realmd.conf